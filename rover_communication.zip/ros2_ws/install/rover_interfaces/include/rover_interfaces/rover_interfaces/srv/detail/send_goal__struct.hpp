// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from rover_interfaces:srv/SendGoal.idl
// generated code does not contain a copyright notice

#ifndef ROVER_INTERFACES__SRV__DETAIL__SEND_GOAL__STRUCT_HPP_
#define ROVER_INTERFACES__SRV__DETAIL__SEND_GOAL__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__rover_interfaces__srv__SendGoal_Request __attribute__((deprecated))
#else
# define DEPRECATED__rover_interfaces__srv__SendGoal_Request __declspec(deprecated)
#endif

namespace rover_interfaces
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct SendGoal_Request_
{
  using Type = SendGoal_Request_<ContainerAllocator>;

  explicit SendGoal_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->location = "";
    }
  }

  explicit SendGoal_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : location(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->location = "";
    }
  }

  // field types and members
  using _location_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _location_type location;

  // setters for named parameter idiom
  Type & set__location(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->location = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    rover_interfaces::srv::SendGoal_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const rover_interfaces::srv::SendGoal_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<rover_interfaces::srv::SendGoal_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<rover_interfaces::srv::SendGoal_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      rover_interfaces::srv::SendGoal_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<rover_interfaces::srv::SendGoal_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      rover_interfaces::srv::SendGoal_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<rover_interfaces::srv::SendGoal_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<rover_interfaces::srv::SendGoal_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<rover_interfaces::srv::SendGoal_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__rover_interfaces__srv__SendGoal_Request
    std::shared_ptr<rover_interfaces::srv::SendGoal_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__rover_interfaces__srv__SendGoal_Request
    std::shared_ptr<rover_interfaces::srv::SendGoal_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SendGoal_Request_ & other) const
  {
    if (this->location != other.location) {
      return false;
    }
    return true;
  }
  bool operator!=(const SendGoal_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SendGoal_Request_

// alias to use template instance with default allocator
using SendGoal_Request =
  rover_interfaces::srv::SendGoal_Request_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace rover_interfaces


#ifndef _WIN32
# define DEPRECATED__rover_interfaces__srv__SendGoal_Response __attribute__((deprecated))
#else
# define DEPRECATED__rover_interfaces__srv__SendGoal_Response __declspec(deprecated)
#endif

namespace rover_interfaces
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct SendGoal_Response_
{
  using Type = SendGoal_Response_<ContainerAllocator>;

  explicit SendGoal_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
    }
  }

  explicit SendGoal_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
    }
  }

  // field types and members
  using _success_type =
    bool;
  _success_type success;

  // setters for named parameter idiom
  Type & set__success(
    const bool & _arg)
  {
    this->success = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    rover_interfaces::srv::SendGoal_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const rover_interfaces::srv::SendGoal_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<rover_interfaces::srv::SendGoal_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<rover_interfaces::srv::SendGoal_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      rover_interfaces::srv::SendGoal_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<rover_interfaces::srv::SendGoal_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      rover_interfaces::srv::SendGoal_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<rover_interfaces::srv::SendGoal_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<rover_interfaces::srv::SendGoal_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<rover_interfaces::srv::SendGoal_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__rover_interfaces__srv__SendGoal_Response
    std::shared_ptr<rover_interfaces::srv::SendGoal_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__rover_interfaces__srv__SendGoal_Response
    std::shared_ptr<rover_interfaces::srv::SendGoal_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SendGoal_Response_ & other) const
  {
    if (this->success != other.success) {
      return false;
    }
    return true;
  }
  bool operator!=(const SendGoal_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SendGoal_Response_

// alias to use template instance with default allocator
using SendGoal_Response =
  rover_interfaces::srv::SendGoal_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace rover_interfaces

namespace rover_interfaces
{

namespace srv
{

struct SendGoal
{
  using Request = rover_interfaces::srv::SendGoal_Request;
  using Response = rover_interfaces::srv::SendGoal_Response;
};

}  // namespace srv

}  // namespace rover_interfaces

#endif  // ROVER_INTERFACES__SRV__DETAIL__SEND_GOAL__STRUCT_HPP_
