// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from rover_interfaces:srv/SendGoal.idl
// generated code does not contain a copyright notice

#ifndef ROVER_INTERFACES__SRV__DETAIL__SEND_GOAL__STRUCT_H_
#define ROVER_INTERFACES__SRV__DETAIL__SEND_GOAL__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'location'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/SendGoal in the package rover_interfaces.
typedef struct rover_interfaces__srv__SendGoal_Request
{
  rosidl_runtime_c__String location;
} rover_interfaces__srv__SendGoal_Request;

// Struct for a sequence of rover_interfaces__srv__SendGoal_Request.
typedef struct rover_interfaces__srv__SendGoal_Request__Sequence
{
  rover_interfaces__srv__SendGoal_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} rover_interfaces__srv__SendGoal_Request__Sequence;


// Constants defined in the message

/// Struct defined in srv/SendGoal in the package rover_interfaces.
typedef struct rover_interfaces__srv__SendGoal_Response
{
  bool success;
} rover_interfaces__srv__SendGoal_Response;

// Struct for a sequence of rover_interfaces__srv__SendGoal_Response.
typedef struct rover_interfaces__srv__SendGoal_Response__Sequence
{
  rover_interfaces__srv__SendGoal_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} rover_interfaces__srv__SendGoal_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ROVER_INTERFACES__SRV__DETAIL__SEND_GOAL__STRUCT_H_
