// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from rover_interfaces:srv/SendGoal.idl
// generated code does not contain a copyright notice

#ifndef ROVER_INTERFACES__SRV__DETAIL__SEND_GOAL__TRAITS_HPP_
#define ROVER_INTERFACES__SRV__DETAIL__SEND_GOAL__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "rover_interfaces/srv/detail/send_goal__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace rover_interfaces
{

namespace srv
{

inline void to_flow_style_yaml(
  const SendGoal_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: location
  {
    out << "location: ";
    rosidl_generator_traits::value_to_yaml(msg.location, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const SendGoal_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: location
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "location: ";
    rosidl_generator_traits::value_to_yaml(msg.location, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const SendGoal_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace rover_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use rover_interfaces::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const rover_interfaces::srv::SendGoal_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  rover_interfaces::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use rover_interfaces::srv::to_yaml() instead")]]
inline std::string to_yaml(const rover_interfaces::srv::SendGoal_Request & msg)
{
  return rover_interfaces::srv::to_yaml(msg);
}

template<>
inline const char * data_type<rover_interfaces::srv::SendGoal_Request>()
{
  return "rover_interfaces::srv::SendGoal_Request";
}

template<>
inline const char * name<rover_interfaces::srv::SendGoal_Request>()
{
  return "rover_interfaces/srv/SendGoal_Request";
}

template<>
struct has_fixed_size<rover_interfaces::srv::SendGoal_Request>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<rover_interfaces::srv::SendGoal_Request>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<rover_interfaces::srv::SendGoal_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rover_interfaces
{

namespace srv
{

inline void to_flow_style_yaml(
  const SendGoal_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: success
  {
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const SendGoal_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: success
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const SendGoal_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace rover_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use rover_interfaces::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const rover_interfaces::srv::SendGoal_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  rover_interfaces::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use rover_interfaces::srv::to_yaml() instead")]]
inline std::string to_yaml(const rover_interfaces::srv::SendGoal_Response & msg)
{
  return rover_interfaces::srv::to_yaml(msg);
}

template<>
inline const char * data_type<rover_interfaces::srv::SendGoal_Response>()
{
  return "rover_interfaces::srv::SendGoal_Response";
}

template<>
inline const char * name<rover_interfaces::srv::SendGoal_Response>()
{
  return "rover_interfaces/srv/SendGoal_Response";
}

template<>
struct has_fixed_size<rover_interfaces::srv::SendGoal_Response>
  : std::integral_constant<bool, true> {};

template<>
struct has_bounded_size<rover_interfaces::srv::SendGoal_Response>
  : std::integral_constant<bool, true> {};

template<>
struct is_message<rover_interfaces::srv::SendGoal_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<rover_interfaces::srv::SendGoal>()
{
  return "rover_interfaces::srv::SendGoal";
}

template<>
inline const char * name<rover_interfaces::srv::SendGoal>()
{
  return "rover_interfaces/srv/SendGoal";
}

template<>
struct has_fixed_size<rover_interfaces::srv::SendGoal>
  : std::integral_constant<
    bool,
    has_fixed_size<rover_interfaces::srv::SendGoal_Request>::value &&
    has_fixed_size<rover_interfaces::srv::SendGoal_Response>::value
  >
{
};

template<>
struct has_bounded_size<rover_interfaces::srv::SendGoal>
  : std::integral_constant<
    bool,
    has_bounded_size<rover_interfaces::srv::SendGoal_Request>::value &&
    has_bounded_size<rover_interfaces::srv::SendGoal_Response>::value
  >
{
};

template<>
struct is_service<rover_interfaces::srv::SendGoal>
  : std::true_type
{
};

template<>
struct is_service_request<rover_interfaces::srv::SendGoal_Request>
  : std::true_type
{
};

template<>
struct is_service_response<rover_interfaces::srv::SendGoal_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // ROVER_INTERFACES__SRV__DETAIL__SEND_GOAL__TRAITS_HPP_
