// generated from rosidl_generator_c/resource/idl.h.em
// with input from rover_interfaces:srv/SendGoal.idl
// generated code does not contain a copyright notice

#ifndef ROVER_INTERFACES__SRV__SEND_GOAL_H_
#define ROVER_INTERFACES__SRV__SEND_GOAL_H_

#include "rover_interfaces/srv/detail/send_goal__struct.h"
#include "rover_interfaces/srv/detail/send_goal__functions.h"
#include "rover_interfaces/srv/detail/send_goal__type_support.h"

#endif  // ROVER_INTERFACES__SRV__SEND_GOAL_H_
