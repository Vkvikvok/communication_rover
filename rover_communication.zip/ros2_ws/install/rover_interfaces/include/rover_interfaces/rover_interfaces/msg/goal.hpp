// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROVER_INTERFACES__MSG__GOAL_HPP_
#define ROVER_INTERFACES__MSG__GOAL_HPP_

#include "rover_interfaces/msg/detail/goal__struct.hpp"
#include "rover_interfaces/msg/detail/goal__builder.hpp"
#include "rover_interfaces/msg/detail/goal__traits.hpp"

#endif  // ROVER_INTERFACES__MSG__GOAL_HPP_
