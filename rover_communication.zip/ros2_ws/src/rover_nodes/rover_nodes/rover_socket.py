#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
import socket
import struct
from rover_interfaces.msg import Goal 

#Bu dosya içerisinde navigasyon noduna gelen veriyi yollayacak bir publisher ve topic yazılacak

class SendGoalServerNode(Node):
    def __init__(self):
        super().__init__("rover_socket")
        self.publisher_ = self.create_publisher(Goal, "send_goal", 10)
        self.timer_ = self.create_timer(0.5, self.publish_goal)
        self.get_logger().info("Rover socket node has been started.")

        
    def receive_goal(self):#Sunucudan veriyi çekmesi için yazılmış bir fonksiyon
        try:

            #Socket örneği oluşturuldu(IPv4, UDP, sürekli bağlantıyı kontrol edecek şekilde ayarlandı)
            socket_receiver = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

            #Sunucuya bağlandı
            socket_receiver.bind(("localhost", 8000))

            # Mesajı al
            data, address = socket_receiver.recvfrom(1024)

            #Mesajı aldıktan sonra socket kapatıldı
            socket_receiver.close()

            return data.decode("utf-8")

        except socket.error as e:
            # Bağlantı kurulamadı!
            self.get_logger().error(f"There is a {e}")

        
        

    def publish_goal(self):
        msg = Goal() #Sadece "location" verisini içeren bir message tipi
        data = self.receive_goal()
        if type(data) == str:
            msg.location = data
            self.publisher_.publish(msg)
            
        else:
            pass

    

def main(args=None):
    rclpy.init(args=args)
    node = SendGoalServerNode()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == "__main__":
    main()