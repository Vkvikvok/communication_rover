#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
import socket
from rover_interfaces.srv import SendGoal 
import struct
#Bu dosya içerisinde terminatorden call fonksiyonuyla mesaj gönderebileceğimiz bir server oluşturulacak.
#Ardından buradan alınan mesajı socket ile diğer bilgisayara göndereceğiz.

class SendGoalServerNode(Node):
    def __init__(self):
        super().__init__("pc_server")
        self.server_ = self.create_service(SendGoal, "send_goal", self.callback_send_goal)
        self.get_logger().info("Send goal server has been started.")
        
        

    def callback_send_goal(self, request, response):
        
        self.socket_client(request.location)
        response.success = True
        return response  
    
    def socket_client(self, location):
        try:
            #Socket örneği oluşturuldu(IPv4, UDP, sürekli bağlantıyı kontrol edecek şekilde ayarlandı)
            socket_ = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        
            #Gelen veriyi encode et ve adresi tanımla
            data = location.encode("utf-8")
            address = ("localhost", 8000)

            #Veriyi gönder
            socket_.sendto(data, address)
            self.get_logger().info("The location" + location + "sent as a goal")
        
        except socket.error as e:
            # Bağlantı kurulamadı!
            self.get_logger().error(f"There is a {e}")

        #Socketi kapat
        socket_.close()

        return True
      

def main(args=None):
    rclpy.init(args=args)
    node = SendGoalServerNode()
    rclpy.spin(node)
    rclpy.shutdown()


if __name__ == "__main__":
    main()