from rover_interfaces.msg._goal import Goal  # noqa: F401
