// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from rover_interfaces:msg/Goal.idl
// generated code does not contain a copyright notice

#ifndef ROVER_INTERFACES__MSG__DETAIL__GOAL__BUILDER_HPP_
#define ROVER_INTERFACES__MSG__DETAIL__GOAL__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "rover_interfaces/msg/detail/goal__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace rover_interfaces
{

namespace msg
{

namespace builder
{

class Init_Goal_location
{
public:
  Init_Goal_location()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::rover_interfaces::msg::Goal location(::rover_interfaces::msg::Goal::_location_type arg)
  {
    msg_.location = std::move(arg);
    return std::move(msg_);
  }

private:
  ::rover_interfaces::msg::Goal msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::rover_interfaces::msg::Goal>()
{
  return rover_interfaces::msg::builder::Init_Goal_location();
}

}  // namespace rover_interfaces

#endif  // ROVER_INTERFACES__MSG__DETAIL__GOAL__BUILDER_HPP_
