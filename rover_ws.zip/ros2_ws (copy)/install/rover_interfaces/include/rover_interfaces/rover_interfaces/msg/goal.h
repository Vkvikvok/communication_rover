// generated from rosidl_generator_c/resource/idl.h.em
// with input from rover_interfaces:msg/Goal.idl
// generated code does not contain a copyright notice

#ifndef ROVER_INTERFACES__MSG__GOAL_H_
#define ROVER_INTERFACES__MSG__GOAL_H_

#include "rover_interfaces/msg/detail/goal__struct.h"
#include "rover_interfaces/msg/detail/goal__functions.h"
#include "rover_interfaces/msg/detail/goal__type_support.h"

#endif  // ROVER_INTERFACES__MSG__GOAL_H_
