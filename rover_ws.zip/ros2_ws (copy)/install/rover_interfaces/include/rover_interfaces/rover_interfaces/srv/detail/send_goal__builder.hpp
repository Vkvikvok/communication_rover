// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from rover_interfaces:srv/SendGoal.idl
// generated code does not contain a copyright notice

#ifndef ROVER_INTERFACES__SRV__DETAIL__SEND_GOAL__BUILDER_HPP_
#define ROVER_INTERFACES__SRV__DETAIL__SEND_GOAL__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "rover_interfaces/srv/detail/send_goal__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace rover_interfaces
{

namespace srv
{

namespace builder
{

class Init_SendGoal_Request_location
{
public:
  Init_SendGoal_Request_location()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::rover_interfaces::srv::SendGoal_Request location(::rover_interfaces::srv::SendGoal_Request::_location_type arg)
  {
    msg_.location = std::move(arg);
    return std::move(msg_);
  }

private:
  ::rover_interfaces::srv::SendGoal_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::rover_interfaces::srv::SendGoal_Request>()
{
  return rover_interfaces::srv::builder::Init_SendGoal_Request_location();
}

}  // namespace rover_interfaces


namespace rover_interfaces
{

namespace srv
{

namespace builder
{

class Init_SendGoal_Response_success
{
public:
  Init_SendGoal_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::rover_interfaces::srv::SendGoal_Response success(::rover_interfaces::srv::SendGoal_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return std::move(msg_);
  }

private:
  ::rover_interfaces::srv::SendGoal_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::rover_interfaces::srv::SendGoal_Response>()
{
  return rover_interfaces::srv::builder::Init_SendGoal_Response_success();
}

}  // namespace rover_interfaces

#endif  // ROVER_INTERFACES__SRV__DETAIL__SEND_GOAL__BUILDER_HPP_
