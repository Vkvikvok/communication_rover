// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROVER_INTERFACES__SRV__SEND_GOAL_HPP_
#define ROVER_INTERFACES__SRV__SEND_GOAL_HPP_

#include "rover_interfaces/srv/detail/send_goal__struct.hpp"
#include "rover_interfaces/srv/detail/send_goal__builder.hpp"
#include "rover_interfaces/srv/detail/send_goal__traits.hpp"

#endif  // ROVER_INTERFACES__SRV__SEND_GOAL_HPP_
