#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
import socket
import struct
from rover_interfaces.msg import Goal 

#Bu dosya içerisinde navigasyon noduna gelen veriyi yollayacak bir publisher ve topic yazılacak

class SendGoalServerNode(Node):
    def __init__(self):
        super().__init__("rover_socket")
        self.publisher_ = self.create_publisher(Goal, "send_goal", 10)
        self.timer_ = self.create_timer(0.5, self.publish_goal)

        #Socket örneği oluşturuldu(IPv4, UDP, sürekli bağlantıyı kontrol edecek şekilde ayarlandı)
        self.socket_receiver = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    def receive_goal(self):#Sunucudan veriyi çekmesi için yazılmış bir fonksiyon
        try:
            #Sunucuya bağlandı
            self.socket_receiver.bind(("144.122.4.143", 12345))

            #Gelen bağlantıları dinlemek için soketi hazırla (en fazla 1 bağlantı bekleyebilir)
            self.socket_receiver.listen(1)

            #Sunucudan gelen bağlantıyı kabul et
            conn, add = self.socket_receiver.accept()

            #PC den gelen gps verisini alacak ve decode edecek
            data = self.socket_receiver.recv(1024).decode("utf-8") #1024 byte veri alacak

            return data

        except socket.error as e:
            # Bağlantı kurulamadı!
            self.get_logger().error(f"There is a {e}")

        #Socket kapatıldı
        self.socket_receiver.close()

    def publish_goal(self):
        msg = Goal() #Sadece "location" verisini içeren bir message tipi

        msg.location = self.receive_goal
        self.publisher_.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = SendGoalServerNode()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == "__main__":
    main()