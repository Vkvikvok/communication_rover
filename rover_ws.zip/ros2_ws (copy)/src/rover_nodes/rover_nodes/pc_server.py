#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
import socket
from rover_interfaces.srv import SendGoal 
import struct
#Bu dosya içerisinde terminatorden call fonksiyonuyla mesaj gönderebileceğimiz bir server oluşturulacak.
#Ardından buradan alınan mesajı socket ile diğer bilgisayara göndereceğiz.

class SendGoalServerNode(Node):
    def __init__(self):
        super().__init__("pc_server")
        self.server_ = self.create_service(SendGoal, "send_goal", self.callback_send_goal)
        self.get_logger().info("Send goal server has been started.")
        #Socket örneği oluşturuldu(IPv4, UDP, sürekli bağlantıyı kontrol edecek şekilde ayarlandı)
        self.socket_client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        

    def callback_send_goal(self, request, response):
        try:
            #Sunucu bilgileri
            server_ip = "144.122.4.143"
            server_port = 12345

            #Serverdan aldığın request i encode et
            data = request.location.encode("utf-8")
            #data = struct.pack(f'!{len(navigation_data)}s', navigation_data.encode())

            #Veriyi socketden yolla
            self.socket_client.sendto(data, (server_ip, server_port))

            self.get_logger().info("The location" + request.location + "sent as a goal")
            #Socket kapatıldı
            

        except socket.error as e:
            # Bağlantı kurulamadı!
            self.get_logger().error(f"There is a {e}")
        self.socket_client.close()
        response.success = 1
        return response  
      

def main(args=None):
    rclpy.init(args=args)
    node = SendGoalServerNode()
    rclpy.spin(node)
    rclpy.shutdown()


if __name__ == "__main__":
    main()